from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models import Register
import pandas as pd
def index(request):
	if request.method=="POST":
		p = float(request.POST["txtp"])
		r = float(request.POST["txtr"])
		t = float(request.POST["txtt"])
		si = (p*r*t)/100
		return render(request,"guestapp/index.html",{"res":si})
	return render(request,"guestapp/index.html")

def about(request):
	if(request.session.has_key('uid')):
	  data = request.session['uid'] 
	  s = Register.objects.all()
	  return render(request,"guestapp/about.html",{'data':s,'data1':data})
	else:
	  return redirect("login") 	
def logout(request):
    del request.session["uid"]
    return redirect("login")	  

def findrecord(request):
	if request.method=="POST":
		s = Register.objects.get(pk=request.POST["txtid"])
		s.name = request.POST["txtname"]
		s.password=request.POST["txtpass"]
		s.gender = request.POST["txtgen"]
		s.jobtype = request.POST["txtjt"]
		s.save()
		return redirect("about")

	s = Register.objects.get(pk=request.GET["q"]) # select * from Register where id=param
	return render(request,"guestapp/findrecord.html",{'d':s})

def findrecord1(request):
	if request.method=="POST":
		s = Register.objects.get(pk=request.POST["txtid"])
		
		s.delete()
		return redirect("about")

	s = Register.objects.get(pk=request.GET["q"]) # select * from Register where id=param
	return render(request,"guestapp/findrecord1.html",{'d':s})

def add(request):
	
	return render(request,"guestapp/addition.html")

def addlogic(request):
 		a = int(request.POST["txtp"])
 		b = int(request.POST["txtr"])
 		c = a+b
 		return render(request,"guestapp/addlogic.html",{"key":c,"v1":a,"v2":b}) 
def reg(request):
	if request.method=="POST":
		name = request.POST["txtname"]
		pa = request.POST["txtpass"]
		gen = request.POST["gen"]
		jt = request.POST.getlist("job[]")
		st = request.POST["state"]
		city= request.POST["city"]
		tech = request.POST.getlist("tech[]")
		j=''
		t=''
		for jt1 in jt:
			j= j+jt1+" "
		for tech1 in tech:
			t = t+ tech1 + " "
		s = "name is "+name+ "password is "+pa + " gender is "+gen
		s1 = "Job type is "+j 
		s2 = "State is "+st + "City is "+city
		s3 = "technology is "+t    
		res = {'info':s,'Job':s1,'location':s2,'tech':s3}	
		obj = Register(name=name,password=pa,gender=gen,jobtype=j,state=st,city=city,tech=t)
		obj.save()	
		return render(request,"guestapp/reg.html",{"key":res})
	return render(request,"guestapp/reg.html") 


def login(request):
	if request.method=="POST":
		uname = request.POST["txtname"]
		upass = request.POST["txtpass"]
		s = Register.objects.filter(name=uname,password=upass)
		if s.count()==1:
			request.session['uid']=uname
			return redirect('about')
		else:
			return render(request,"guestapp/login.html",{"error":"Invalid userid and password"})		
	return render(request,"guestapp/login.html")

