from django.urls import path
from . import views

urlpatterns = [

    path('', views.index, name='index'),
    path('add', views.add, name='add'),
    path('addlogic', views.addlogic, name='addlogic'),
    path('about', views.about, name='about'),
    path('reg', views.reg, name='reg'),
    path('login', views.login, name='login'),
    path('logout', views.logout, name='logout'),
    path('findrecord', views.findrecord, name='findrecord'),
    path('findrecord1', views.findrecord1, name='findrecord1')


 ]