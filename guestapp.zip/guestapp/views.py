from django.shortcuts import render,redirect
from django.http import HttpResponse

def index(request):
	if request.method=="POST":
		p = float(request.POST["txtp"])
		r = float(request.POST["txtr"])
		t = float(request.POST["txtt"])
		si = (p*r*t)/100
		return render(request,"guestapp/index.html",{"res":si})
	return render(request,"guestapp/index.html")

def about(request):
	return HttpResponse("<h1>Welcome in About us</h1>")	

def add(request):
	
	return render(request,"guestapp/addition.html")

def addlogic(request):
 		a = int(request.POST["txtp"])
 		b = int(request.POST["txtr"])
 		c = a+b
 		return render(request,"guestapp/addlogic.html",{"key":c,"v1":a,"v2":b}) 
def reg(request):
	if request.method=="POST":
		name = request.POST["txtname"]
		pa = request.POST["txtpass"]
		gen = request.POST["gen"]
		jt = request.POST.getlist("job[]")
		st = request.POST["state"]
		city= request.POST["city"]
		tech = request.POST.getlist("tech[]")
		j=''
		t=''
		for jt1 in jt:
			j= j+jt1+" "
		for tech1 in tech:
			t = t+ tech1 + " "
		s = "name is "+name+ "password is "+pa + " gender is "+gen
		s1 = "Job type is "+j 
		s2 = "State is "+st + "City is "+city
		s3 = "technology is "+t    
		res = {'info':s,'Job':s1,'location':s2,'tech':s3}		
		return render(request,"guestapp/reg.html",{"key":res})
	return render(request,"guestapp/reg.html") 


def login(request):
	if request.method=="POST":
		uname = request.POST["txtname"]
		upass = request.POST["txtpass"]
		if uname=="SCOTT" and upass=="Tiger":
			return redirect('about')
		else:
			return render(request,"guestapp/login.html",{"error":"Invalid userid and password"})		
	return render(request,"guestapp/login.html")

