from django.shortcuts import render
from django.http import HttpResponse
def index(request):
	return render(request,"admindash/index.html")
def dashsecond(request):
	return render(request,"admindash/index2.html")